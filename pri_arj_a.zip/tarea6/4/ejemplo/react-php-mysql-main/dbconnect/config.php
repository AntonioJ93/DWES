<?php
//nombre del servidor
define('G_SERVIDOR','localhost');

//nombre de la base de datos
define('G_BASEDATOS','db_emocion');

//nombre del usuario
define('G_USUARIO','root');

//clave del usuario
define('G_CLAVE','Fullstack.2021');

?>
